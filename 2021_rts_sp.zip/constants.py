# Purpose: constant declaration
# Author: Nathan Burlis

MAX_JOBS = 5
MAX_TICKS = 120
RUNS = 100000
